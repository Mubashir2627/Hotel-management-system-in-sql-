# Hotel Management System (SQL + PHP Web App)

## Project Contents
- `sql/hotel_management.sql` → Database schema + sample data + useful queries (run this in **SQL Workbench / MySQL**)
- `web/` → PHP web frontend (Dashboard, Rooms, Guests, Bookings, Payments)

## Database Tables (25 Total)
1. **departments** – Front Desk, Housekeeping, F&B, Maintenance, Management
2. **designations** – job titles linked to departments (Manager, Receptionist, etc.)
3. **staff** – employee records
4. **staff_attendance** – daily attendance log
5. **payroll** – monthly salary payment records
6. **roles** – system user roles (Admin, Receptionist, Housekeeping)
7. **users** – login accounts for staff
8. **room_types** – Single, Double, Deluxe, Suite (with prices)
9. **amenities** – AC, Wi-Fi, TV, Mini Bar, Balcony, Heater
10. **rooms** – room number, floor, type, status
11. **room_amenities** – many-to-many link between rooms & amenities
12. **room_rates** – seasonal/special pricing per room type
13. **guests** – guest details
14. **discounts** – promo codes / offers
15. **bookings** – reservations linking guests + rooms + staff + discounts
16. **payments** – payment records linked to bookings
17. **refunds** – cancellation/refund records
18. **services** – extra services (laundry, spa, airport pickup, etc.)
19. **service_bookings** – services availed per booking
20. **housekeeping_tasks** – room cleaning task tracking
21. **maintenance_requests** – room repair/issue tracking
22. **suppliers** – vendor details
23. **inventory_items** – hotel stock (linens, toiletries, kitchen supplies)
24. **purchase_orders** – stock orders placed to suppliers
25. **feedback** – guest reviews and complaints

## How to Run (Step by Step)

### 1. Setup Database (SQL Workbench / MySQL)
1. Open MySQL Workbench
2. Open the file `sql/hotel_management.sql`
3. Run the entire script (it creates the database `hotel_management`, all tables, and inserts sample data)

### 2. Setup Web App (XAMPP / WAMP)
1. Install **XAMPP** (includes PHP + MySQL + Apache)
2. Start **Apache** and **MySQL** from XAMPP control panel
3. Copy the `web` folder into:
   - Windows: `C:\xampp\htdocs\hotel_management`
   - (rename the folder to `hotel_management` if needed)
4. Open `web/db_connect.php` and check these settings match your MySQL setup:
   ```php
   $host = "localhost";
   $username = "root";
   $password = "";   // usually empty in XAMPP
   $dbname = "hotel_management";
   ```
5. Open your browser and go to:
   ```
   http://localhost/hotel_management/index.php
   ```

### 3. Using the App
- **Dashboard** – overview stats (total rooms, available rooms, guests, bookings, revenue)
- **Rooms** – add rooms, update room status, delete rooms
- **Guests** – register and manage guest records
- **Bookings** – create new bookings (amount auto-calculated based on room type & nights), update booking status (auto frees room on checkout/cancel)
- **Payments** – record payments, view outstanding balances and payment history

## For Project Presentation
- Show the ER relationships: room_types → rooms → bookings ← guests, bookings → payments, staff → bookings
- Demonstrate live CRUD operations through the web pages
- Run the sample queries at the bottom of `hotel_management.sql` in Workbench to show JOINs, aggregate functions (SUM, COUNT), GROUP BY, HAVING
