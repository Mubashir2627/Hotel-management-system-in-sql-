<?php
// Database connection settings
// CHANGE these values according to your MySQL setup
$host = "localhost";
$username = "root";
$password = "";          // your MySQL root password (often empty on XAMPP)
$dbname = "hotel_management";

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
