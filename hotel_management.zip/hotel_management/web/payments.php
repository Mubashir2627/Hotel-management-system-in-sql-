<?php
include 'db_connect.php';
$message = "";

if (isset($_POST['add_payment'])) {
    $booking_id = (int)$_POST['booking_id'];
    $amount = (float)$_POST['amount_paid'];
    $method = $_POST['payment_method'];

    $sql = "INSERT INTO payments (booking_id, amount_paid, payment_method) VALUES ($booking_id, $amount, '$method')";
    if ($conn->query($sql)) {
        $message = "Payment recorded successfully.";
    } else {
        $message = "Error: " . $conn->error;
    }
}

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM payments WHERE payment_id = $id");
    $message = "Payment record deleted.";
}

$bookings = $conn->query("SELECT b.booking_id, g.full_name, b.total_amount FROM bookings b JOIN guests g ON b.guest_id=g.guest_id ORDER BY b.booking_id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payments - Hotel Management System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="navbar">
    <h1>🏨 Hotel Management System</h1>
    <nav>
        <a href="index.php">Dashboard</a>
        <a href="rooms.php">Rooms</a>
        <a href="guests.php">Guests</a>
        <a href="bookings.php">Bookings</a>
        <a href="payments.php" class="active">Payments</a>
    </nav>
</div>

<div class="container">
    <h2 class="page-title">Manage Payments</h2>

    <?php if ($message) echo "<div class='alert'>$message</div>"; ?>

    <div class="form-box">
        <h2>Record New Payment</h2>
        <form method="POST">
            <div class="form-group">
                <label>Booking</label>
                <select name="booking_id" required>
                    <?php $bookings->data_seek(0); while ($b = $bookings->fetch_assoc()) {
                        echo "<option value='{$b['booking_id']}'>#{$b['booking_id']} - {$b['full_name']} (Total: Rs. " . number_format($b['total_amount'],2) . ")</option>";
                    } ?>
                </select>
            </div>
            <div class="form-group">
                <label>Amount Paid</label>
                <input type="number" step="0.01" name="amount_paid" required>
            </div>
            <div class="form-group">
                <label>Payment Method</label>
                <select name="payment_method">
                    <option value="Cash">Cash</option>
                    <option value="Card">Card</option>
                    <option value="Online">Online</option>
                </select>
            </div>
            <button type="submit" name="add_payment">Record Payment</button>
        </form>
    </div>

    <h2 class="page-title">Outstanding Balances</h2>
    <table>
        <tr>
            <th>Booking ID</th>
            <th>Guest</th>
            <th>Total Amount</th>
            <th>Paid</th>
            <th>Balance Due</th>
        </tr>
        <?php
        $balRes = $conn->query("SELECT b.booking_id, g.full_name, b.total_amount,
                                        IFNULL(SUM(p.amount_paid),0) AS paid,
                                        (b.total_amount - IFNULL(SUM(p.amount_paid),0)) AS balance
                                 FROM bookings b
                                 JOIN guests g ON b.guest_id = g.guest_id
                                 LEFT JOIN payments p ON b.booking_id = p.booking_id
                                 GROUP BY b.booking_id
                                 HAVING balance > 0");
        if ($balRes->num_rows > 0) {
            while ($row = $balRes->fetch_assoc()) {
                echo "<tr>
                        <td>#{$row['booking_id']}</td>
                        <td>{$row['full_name']}</td>
                        <td>Rs. " . number_format($row['total_amount'],2) . "</td>
                        <td>Rs. " . number_format($row['paid'],2) . "</td>
                        <td>Rs. " . number_format($row['balance'],2) . "</td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='5' class='empty-msg'>No outstanding balances.</td></tr>";
        }
        ?>
    </table>

    <br>
    <h2 class="page-title">Payment History</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Booking ID</th>
            <th>Guest</th>
            <th>Amount Paid</th>
            <th>Date</th>
            <th>Method</th>
            <th>Action</th>
        </tr>
        <?php
        $result = $conn->query("SELECT p.payment_id, p.booking_id, g.full_name, p.amount_paid, p.payment_date, p.payment_method
                                 FROM payments p
                                 JOIN bookings b ON p.booking_id = b.booking_id
                                 JOIN guests g ON b.guest_id = g.guest_id
                                 ORDER BY p.payment_id DESC");
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['payment_id']}</td>
                        <td>#{$row['booking_id']}</td>
                        <td>{$row['full_name']}</td>
                        <td>Rs. " . number_format($row['amount_paid'],2) . "</td>
                        <td>{$row['payment_date']}</td>
                        <td>{$row['payment_method']}</td>
                        <td class='actions'>
                            <a href='payments.php?delete={$row['payment_id']}' class='btn btn-danger' onclick=\"return confirm('Delete this payment?')\">Delete</a>
                        </td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='7' class='empty-msg'>No payments recorded.</td></tr>";
        }
        ?>
    </table>
</div>

</body>
</html>
