<?php
include 'db_connect.php';

$total_rooms = $conn->query("SELECT COUNT(*) AS c FROM rooms")->fetch_assoc()['c'];
$available_rooms = $conn->query("SELECT COUNT(*) AS c FROM rooms WHERE status='Available'")->fetch_assoc()['c'];
$total_guests = $conn->query("SELECT COUNT(*) AS c FROM guests")->fetch_assoc()['c'];
$active_bookings = $conn->query("SELECT COUNT(*) AS c FROM bookings WHERE booking_status IN ('Confirmed','Checked-In')")->fetch_assoc()['c'];
$revenue = $conn->query("SELECT IFNULL(SUM(amount_paid),0) AS r FROM payments")->fetch_assoc()['r'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hotel Management System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="navbar">
    <h1>🏨 Hotel Management System</h1>
    <nav>
        <a href="index.php" class="active">Dashboard</a>
        <a href="rooms.php">Rooms</a>
        <a href="guests.php">Guests</a>
        <a href="bookings.php">Bookings</a>
        <a href="payments.php">Payments</a>
    </nav>
</div>

<div class="container">
    <h2 class="page-title">Dashboard</h2>

    <div class="stats">
        <div class="stat-card">
            <h3><?php echo $total_rooms; ?></h3>
            <p>Total Rooms</p>
        </div>
        <div class="stat-card">
            <h3><?php echo $available_rooms; ?></h3>
            <p>Available Rooms</p>
        </div>
        <div class="stat-card">
            <h3><?php echo $total_guests; ?></h3>
            <p>Registered Guests</p>
        </div>
        <div class="stat-card">
            <h3><?php echo $active_bookings; ?></h3>
            <p>Active Bookings</p>
        </div>
        <div class="stat-card">
            <h3>Rs. <?php echo number_format($revenue, 2); ?></h3>
            <p>Total Revenue Collected</p>
        </div>
    </div>

    <h2 class="page-title">Recent Bookings</h2>
    <table>
        <tr>
            <th>Booking ID</th>
            <th>Guest</th>
            <th>Room</th>
            <th>Check-In</th>
            <th>Check-Out</th>
            <th>Status</th>
        </tr>
        <?php
        $result = $conn->query("SELECT b.booking_id, g.full_name, r.room_number, b.check_in, b.check_out, b.booking_status
                                 FROM bookings b
                                 JOIN guests g ON b.guest_id = g.guest_id
                                 JOIN rooms r ON b.room_id = r.room_id
                                 ORDER BY b.booking_id DESC LIMIT 5");
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $statusClass = strtolower(str_replace(' ', '-', $row['booking_status']));
                echo "<tr>
                        <td>#{$row['booking_id']}</td>
                        <td>{$row['full_name']}</td>
                        <td>{$row['room_number']}</td>
                        <td>{$row['check_in']}</td>
                        <td>{$row['check_out']}</td>
                        <td><span class='badge badge-{$statusClass}'>{$row['booking_status']}</span></td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='6' class='empty-msg'>No bookings found.</td></tr>";
        }
        ?>
    </table>
</div>

</body>
</html>
