<?php
include 'db_connect.php';
$message = "";

if (isset($_POST['add_guest'])) {
    $name = $conn->real_escape_string($_POST['full_name']);
    $cnic = $conn->real_escape_string($_POST['cnic']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $email = $conn->real_escape_string($_POST['email']);
    $address = $conn->real_escape_string($_POST['address']);

    $sql = "INSERT INTO guests (full_name, cnic, phone, email, address) VALUES ('$name','$cnic','$phone','$email','$address')";
    if ($conn->query($sql)) {
        $message = "Guest registered successfully.";
    } else {
        $message = "Error: " . $conn->error;
    }
}

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM guests WHERE guest_id = $id");
    $message = "Guest record deleted.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Guests - Hotel Management System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="navbar">
    <h1>🏨 Hotel Management System</h1>
    <nav>
        <a href="index.php">Dashboard</a>
        <a href="rooms.php">Rooms</a>
        <a href="guests.php" class="active">Guests</a>
        <a href="bookings.php">Bookings</a>
        <a href="payments.php">Payments</a>
    </nav>
</div>

<div class="container">
    <h2 class="page-title">Manage Guests</h2>

    <?php if ($message) echo "<div class='alert'>$message</div>"; ?>

    <div class="form-box">
        <h2>Register New Guest</h2>
        <form method="POST">
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" name="full_name" required>
            </div>
            <div class="form-group">
                <label>CNIC</label>
                <input type="text" name="cnic" placeholder="35202-1234567-1">
            </div>
            <div class="form-group">
                <label>Phone</label>
                <input type="text" name="phone" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email">
            </div>
            <div class="form-group">
                <label>Address</label>
                <textarea name="address" rows="2"></textarea>
            </div>
            <button type="submit" name="add_guest">Register Guest</button>
        </form>
    </div>

    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>CNIC</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Registered On</th>
            <th>Action</th>
        </tr>
        <?php
        $result = $conn->query("SELECT * FROM guests ORDER BY guest_id DESC");
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['guest_id']}</td>
                        <td>{$row['full_name']}</td>
                        <td>{$row['cnic']}</td>
                        <td>{$row['phone']}</td>
                        <td>{$row['email']}</td>
                        <td>{$row['registered_on']}</td>
                        <td class='actions'>
                            <a href='guests.php?delete={$row['guest_id']}' class='btn btn-danger' onclick=\"return confirm('Delete this guest?')\">Delete</a>
                        </td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='7' class='empty-msg'>No guests found.</td></tr>";
        }
        ?>
    </table>
</div>

</body>
</html>
