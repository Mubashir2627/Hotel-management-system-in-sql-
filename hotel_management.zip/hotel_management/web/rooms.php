<?php
include 'db_connect.php';
$message = "";

// Add new room
if (isset($_POST['add_room'])) {
    $room_number = $conn->real_escape_string($_POST['room_number']);
    $type_id = (int)$_POST['type_id'];
    $floor_number = (int)$_POST['floor_number'];
    $status = $_POST['status'];

    $sql = "INSERT INTO rooms (room_number, type_id, floor_number, status) VALUES ('$room_number', $type_id, $floor_number, '$status')";
    if ($conn->query($sql)) {
        $message = "Room added successfully.";
    } else {
        $message = "Error: " . $conn->error;
    }
}

// Delete room
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM rooms WHERE room_id = $id");
    $message = "Room deleted.";
}

// Update status
if (isset($_POST['update_status'])) {
    $id = (int)$_POST['room_id'];
    $status = $_POST['status'];
    $conn->query("UPDATE rooms SET status='$status' WHERE room_id=$id");
    $message = "Room status updated.";
}

$room_types = $conn->query("SELECT * FROM room_types");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Rooms - Hotel Management System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="navbar">
    <h1>🏨 Hotel Management System</h1>
    <nav>
        <a href="index.php">Dashboard</a>
        <a href="rooms.php" class="active">Rooms</a>
        <a href="guests.php">Guests</a>
        <a href="bookings.php">Bookings</a>
        <a href="payments.php">Payments</a>
    </nav>
</div>

<div class="container">
    <h2 class="page-title">Manage Rooms</h2>

    <?php if ($message) echo "<div class='alert'>$message</div>"; ?>

    <div class="form-box">
        <h2>Add New Room</h2>
        <form method="POST">
            <div class="form-group">
                <label>Room Number</label>
                <input type="text" name="room_number" required>
            </div>
            <div class="form-group">
                <label>Room Type</label>
                <select name="type_id" required>
                    <?php
                    $room_types->data_seek(0);
                    while ($t = $room_types->fetch_assoc()) {
                        echo "<option value='{$t['type_id']}'>{$t['type_name']} (Rs. {$t['price_per_night']}/night)</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label>Floor Number</label>
                <input type="number" name="floor_number" min="1" required>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="Available">Available</option>
                    <option value="Occupied">Occupied</option>
                    <option value="Maintenance">Maintenance</option>
                </select>
            </div>
            <button type="submit" name="add_room">Add Room</button>
        </form>
    </div>

    <table>
        <tr>
            <th>Room No.</th>
            <th>Type</th>
            <th>Price/Night</th>
            <th>Floor</th>
            <th>Status</th>
            <th>Update Status</th>
            <th>Action</th>
        </tr>
        <?php
        $result = $conn->query("SELECT r.room_id, r.room_number, rt.type_name, rt.price_per_night, r.floor_number, r.status
                                 FROM rooms r JOIN room_types rt ON r.type_id = rt.type_id
                                 ORDER BY r.room_number");
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $statusClass = strtolower($row['status']);
                echo "<tr>
                        <td>{$row['room_number']}</td>
                        <td>{$row['type_name']}</td>
                        <td>Rs. {$row['price_per_night']}</td>
                        <td>{$row['floor_number']}</td>
                        <td><span class='badge badge-{$statusClass}'>{$row['status']}</span></td>
                        <td>
                            <form method='POST' style='display:flex; gap:5px;'>
                                <input type='hidden' name='room_id' value='{$row['room_id']}'>
                                <select name='status'>
                                    <option value='Available'" . ($row['status']=='Available'?' selected':'') . ">Available</option>
                                    <option value='Occupied'" . ($row['status']=='Occupied'?' selected':'') . ">Occupied</option>
                                    <option value='Maintenance'" . ($row['status']=='Maintenance'?' selected':'') . ">Maintenance</option>
                                </select>
                                <button type='submit' name='update_status'>Update</button>
                            </form>
                        </td>
                        <td class='actions'>
                            <a href='rooms.php?delete={$row['room_id']}' class='btn btn-danger' onclick=\"return confirm('Delete this room?')\">Delete</a>
                        </td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='7' class='empty-msg'>No rooms found.</td></tr>";
        }
        ?>
    </table>
</div>

</body>
</html>
