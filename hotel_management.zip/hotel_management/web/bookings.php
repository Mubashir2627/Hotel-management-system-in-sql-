<?php
include 'db_connect.php';
$message = "";

// Add new booking
if (isset($_POST['add_booking'])) {
    $guest_id = (int)$_POST['guest_id'];
    $room_id = (int)$_POST['room_id'];
    $staff_id = (int)$_POST['staff_id'];
    $check_in = $_POST['check_in'];
    $check_out = $_POST['check_out'];

    // Get price per night for selected room
    $priceRes = $conn->query("SELECT rt.price_per_night FROM rooms r JOIN room_types rt ON r.type_id = rt.type_id WHERE r.room_id = $room_id");
    $price = $priceRes->fetch_assoc()['price_per_night'];

    $nights = (strtotime($check_out) - strtotime($check_in)) / (60*60*24);
    if ($nights <= 0) $nights = 1;
    $total = $nights * $price;

    $sql = "INSERT INTO bookings (guest_id, room_id, staff_id, check_in, check_out, total_amount, booking_status)
            VALUES ($guest_id, $room_id, $staff_id, '$check_in', '$check_out', $total, 'Confirmed')";
    if ($conn->query($sql)) {
        // Mark room as Occupied
        $conn->query("UPDATE rooms SET status='Occupied' WHERE room_id = $room_id");
        $message = "Booking created successfully. Total amount: Rs. " . number_format($total, 2);
    } else {
        $message = "Error: " . $conn->error;
    }
}

// Update booking status
if (isset($_POST['update_booking_status'])) {
    $id = (int)$_POST['booking_id'];
    $status = $_POST['booking_status'];
    $conn->query("UPDATE bookings SET booking_status='$status' WHERE booking_id=$id");

    // If checked out or cancelled, free the room
    if ($status == 'Checked-Out' || $status == 'Cancelled') {
        $roomRes = $conn->query("SELECT room_id FROM bookings WHERE booking_id=$id");
        $room_id = $roomRes->fetch_assoc()['room_id'];
        $conn->query("UPDATE rooms SET status='Available' WHERE room_id=$room_id");
    }
    $message = "Booking status updated.";
}

// Delete booking
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM bookings WHERE booking_id = $id");
    $message = "Booking deleted.";
}

$guests = $conn->query("SELECT guest_id, full_name FROM guests ORDER BY full_name");
$rooms = $conn->query("SELECT r.room_id, r.room_number, rt.type_name, rt.price_per_night FROM rooms r JOIN room_types rt ON r.type_id=rt.type_id ORDER BY r.room_number");
$staff = $conn->query("SELECT staff_id, full_name FROM staff ORDER BY full_name");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Bookings - Hotel Management System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="navbar">
    <h1>🏨 Hotel Management System</h1>
    <nav>
        <a href="index.php">Dashboard</a>
        <a href="rooms.php">Rooms</a>
        <a href="guests.php">Guests</a>
        <a href="bookings.php" class="active">Bookings</a>
        <a href="payments.php">Payments</a>
    </nav>
</div>

<div class="container">
    <h2 class="page-title">Manage Bookings</h2>

    <?php if ($message) echo "<div class='alert'>$message</div>"; ?>

    <div class="form-box">
        <h2>New Booking</h2>
        <form method="POST">
            <div class="form-group">
                <label>Guest</label>
                <select name="guest_id" required>
                    <?php $guests->data_seek(0); while ($g = $guests->fetch_assoc()) {
                        echo "<option value='{$g['guest_id']}'>{$g['full_name']}</option>";
                    } ?>
                </select>
            </div>
            <div class="form-group">
                <label>Room</label>
                <select name="room_id" required>
                    <?php $rooms->data_seek(0); while ($r = $rooms->fetch_assoc()) {
                        echo "<option value='{$r['room_id']}'>{$r['room_number']} - {$r['type_name']} (Rs. {$r['price_per_night']}/night)</option>";
                    } ?>
                </select>
            </div>
            <div class="form-group">
                <label>Handled By (Staff)</label>
                <select name="staff_id" required>
                    <?php $staff->data_seek(0); while ($s = $staff->fetch_assoc()) {
                        echo "<option value='{$s['staff_id']}'>{$s['full_name']}</option>";
                    } ?>
                </select>
            </div>
            <div class="form-group">
                <label>Check-In Date</label>
                <input type="date" name="check_in" required>
            </div>
            <div class="form-group">
                <label>Check-Out Date</label>
                <input type="date" name="check_out" required>
            </div>
            <button type="submit" name="add_booking">Create Booking</button>
        </form>
    </div>

    <table>
        <tr>
            <th>ID</th>
            <th>Guest</th>
            <th>Room</th>
            <th>Staff</th>
            <th>Check-In</th>
            <th>Check-Out</th>
            <th>Amount</th>
            <th>Status</th>
            <th>Update</th>
            <th>Action</th>
        </tr>
        <?php
        $result = $conn->query("SELECT b.booking_id, g.full_name AS guest, r.room_number, s.full_name AS staff,
                                        b.check_in, b.check_out, b.total_amount, b.booking_status
                                 FROM bookings b
                                 JOIN guests g ON b.guest_id = g.guest_id
                                 JOIN rooms r ON b.room_id = r.room_id
                                 LEFT JOIN staff s ON b.staff_id = s.staff_id
                                 ORDER BY b.booking_id DESC");
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $statusClass = strtolower(str_replace(' ', '-', $row['booking_status']));
                echo "<tr>
                        <td>#{$row['booking_id']}</td>
                        <td>{$row['guest']}</td>
                        <td>{$row['room_number']}</td>
                        <td>{$row['staff']}</td>
                        <td>{$row['check_in']}</td>
                        <td>{$row['check_out']}</td>
                        <td>Rs. " . number_format($row['total_amount'],2) . "</td>
                        <td><span class='badge badge-{$statusClass}'>{$row['booking_status']}</span></td>
                        <td>
                            <form method='POST' style='display:flex; gap:5px;'>
                                <input type='hidden' name='booking_id' value='{$row['booking_id']}'>
                                <select name='booking_status'>
                                    <option value='Confirmed'" . ($row['booking_status']=='Confirmed'?' selected':'') . ">Confirmed</option>
                                    <option value='Checked-In'" . ($row['booking_status']=='Checked-In'?' selected':'') . ">Checked-In</option>
                                    <option value='Checked-Out'" . ($row['booking_status']=='Checked-Out'?' selected':'') . ">Checked-Out</option>
                                    <option value='Cancelled'" . ($row['booking_status']=='Cancelled'?' selected':'') . ">Cancelled</option>
                                </select>
                                <button type='submit' name='update_booking_status'>Set</button>
                            </form>
                        </td>
                        <td class='actions'>
                            <a href='bookings.php?delete={$row['booking_id']}' class='btn btn-danger' onclick=\"return confirm('Delete this booking?')\">Delete</a>
                        </td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='10' class='empty-msg'>No bookings found.</td></tr>";
        }
        ?>
    </table>
</div>

</body>
</html>
