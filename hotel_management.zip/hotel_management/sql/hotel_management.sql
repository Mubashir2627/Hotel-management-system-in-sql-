-- =========================================================
--  HOTEL MANAGEMENT SYSTEM - FULL DATABASE (25 TABLES)
--  Run this file in MySQL / SQL Workbench
-- =========================================================

DROP DATABASE IF EXISTS hotel_management;
CREATE DATABASE hotel_management;
USE hotel_management;

-- =========================================================
-- 1. DEPARTMENTS
-- =========================================================
CREATE TABLE departments (
    department_id INT AUTO_INCREMENT PRIMARY KEY,
    department_name VARCHAR(50) NOT NULL,
    description VARCHAR(255)
);

-- =========================================================
-- 2. DESIGNATIONS
-- =========================================================
CREATE TABLE designations (
    designation_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(50) NOT NULL,
    department_id INT NOT NULL,
    base_salary DECIMAL(10,2),
    FOREIGN KEY (department_id) REFERENCES departments(department_id)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- =========================================================
-- 3. STAFF / EMPLOYEES
-- =========================================================
CREATE TABLE staff (
    staff_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    designation_id INT NOT NULL,
    phone VARCHAR(20),
    email VARCHAR(100),
    salary DECIMAL(10,2),
    hire_date DATE DEFAULT (CURRENT_DATE),
    FOREIGN KEY (designation_id) REFERENCES designations(designation_id)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- =========================================================
-- 4. STAFF ATTENDANCE
-- =========================================================
CREATE TABLE staff_attendance (
    attendance_id INT AUTO_INCREMENT PRIMARY KEY,
    staff_id INT NOT NULL,
    attendance_date DATE NOT NULL,
    status ENUM('Present','Absent','Leave') DEFAULT 'Present',
    FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- =========================================================
-- 5. PAYROLL
-- =========================================================
CREATE TABLE payroll (
    payroll_id INT AUTO_INCREMENT PRIMARY KEY,
    staff_id INT NOT NULL,
    month_year VARCHAR(7) NOT NULL,   -- format: 'YYYY-MM'
    amount_paid DECIMAL(10,2) NOT NULL,
    payment_date DATE DEFAULT (CURRENT_DATE),
    status ENUM('Paid','Pending') DEFAULT 'Pending',
    FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- =========================================================
-- 6. ROLES (for system login/users)
-- =========================================================
CREATE TABLE roles (
    role_id INT AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(50) NOT NULL UNIQUE,
    description VARCHAR(150)
);

-- =========================================================
-- 7. USERS (system login accounts)
-- =========================================================
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    staff_id INT,
    role_id INT NOT NULL,
    created_on DATE DEFAULT (CURRENT_DATE),
    FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (role_id) REFERENCES roles(role_id)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- =========================================================
-- 8. ROOM TYPES
-- =========================================================
CREATE TABLE room_types (
    type_id INT AUTO_INCREMENT PRIMARY KEY,
    type_name VARCHAR(50) NOT NULL,
    price_per_night DECIMAL(10,2) NOT NULL,
    max_occupancy INT NOT NULL,
    description VARCHAR(255)
);

-- =========================================================
-- 9. AMENITIES
-- =========================================================
CREATE TABLE amenities (
    amenity_id INT AUTO_INCREMENT PRIMARY KEY,
    amenity_name VARCHAR(50) NOT NULL,
    icon VARCHAR(50)
);

-- =========================================================
-- 10. ROOMS
-- =========================================================
CREATE TABLE rooms (
    room_id INT AUTO_INCREMENT PRIMARY KEY,
    room_number VARCHAR(10) NOT NULL UNIQUE,
    type_id INT NOT NULL,
    floor_number INT NOT NULL,
    status ENUM('Available','Occupied','Maintenance') DEFAULT 'Available',
    FOREIGN KEY (type_id) REFERENCES room_types(type_id)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- =========================================================
-- 11. ROOM_AMENITIES (Junction Table - Many to Many)
-- =========================================================
CREATE TABLE room_amenities (
    room_id INT NOT NULL,
    amenity_id INT NOT NULL,
    PRIMARY KEY (room_id, amenity_id),
    FOREIGN KEY (room_id) REFERENCES rooms(room_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (amenity_id) REFERENCES amenities(amenity_id)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- =========================================================
-- 12. ROOM RATES (Seasonal / Special Pricing)
-- =========================================================
CREATE TABLE room_rates (
    rate_id INT AUTO_INCREMENT PRIMARY KEY,
    type_id INT NOT NULL,
    season_name VARCHAR(50) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    price_per_night DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (type_id) REFERENCES room_types(type_id)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- =========================================================
-- 13. GUESTS
-- =========================================================
CREATE TABLE guests (
    guest_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    cnic VARCHAR(20) UNIQUE,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(100),
    address VARCHAR(255),
    registered_on DATE DEFAULT (CURRENT_DATE)
);

-- =========================================================
-- 14. DISCOUNTS / OFFERS
-- =========================================================
CREATE TABLE discounts (
    discount_id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    description VARCHAR(150),
    percentage DECIMAL(5,2) NOT NULL,
    valid_until DATE
);

-- =========================================================
-- 15. BOOKINGS / RESERVATIONS
-- =========================================================
CREATE TABLE bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    guest_id INT NOT NULL,
    room_id INT NOT NULL,
    staff_id INT,
    discount_id INT,
    check_in DATE NOT NULL,
    check_out DATE NOT NULL,
    total_amount DECIMAL(10,2),
    booking_status ENUM('Confirmed','Checked-In','Checked-Out','Cancelled') DEFAULT 'Confirmed',
    FOREIGN KEY (guest_id) REFERENCES guests(guest_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (room_id) REFERENCES rooms(room_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (discount_id) REFERENCES discounts(discount_id)
        ON DELETE SET NULL ON UPDATE CASCADE
);

-- =========================================================
-- 16. PAYMENTS
-- =========================================================
CREATE TABLE payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    amount_paid DECIMAL(10,2) NOT NULL,
    payment_date DATE DEFAULT (CURRENT_DATE),
    payment_method ENUM('Cash','Card','Online') DEFAULT 'Cash',
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- =========================================================
-- 17. REFUNDS / CANCELLATIONS
-- =========================================================
CREATE TABLE refunds (
    refund_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    refund_amount DECIMAL(10,2) NOT NULL,
    reason VARCHAR(255),
    refund_date DATE DEFAULT (CURRENT_DATE),
    status ENUM('Pending','Processed','Rejected') DEFAULT 'Pending',
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- =========================================================
-- 18. SERVICES (Spa, Laundry, Gym, Airport Pickup, etc.)
-- =========================================================
CREATE TABLE services (
    service_id INT AUTO_INCREMENT PRIMARY KEY,
    service_name VARCHAR(100) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    description VARCHAR(255)
);

-- =========================================================
-- 19. SERVICE BOOKINGS
-- =========================================================
CREATE TABLE service_bookings (
    service_booking_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    service_id INT NOT NULL,
    quantity INT DEFAULT 1,
    service_date DATE DEFAULT (CURRENT_DATE),
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(service_id)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- =========================================================
-- 20. HOUSEKEEPING TASKS
-- =========================================================
CREATE TABLE housekeeping_tasks (
    task_id INT AUTO_INCREMENT PRIMARY KEY,
    room_id INT NOT NULL,
    staff_id INT NOT NULL,
    task_date DATE DEFAULT (CURRENT_DATE),
    task_type ENUM('Cleaning','Bed Change','Deep Clean','Restock') DEFAULT 'Cleaning',
    status ENUM('Pending','In Progress','Completed') DEFAULT 'Pending',
    FOREIGN KEY (room_id) REFERENCES rooms(room_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- =========================================================
-- 21. MAINTENANCE REQUESTS
-- =========================================================
CREATE TABLE maintenance_requests (
    request_id INT AUTO_INCREMENT PRIMARY KEY,
    room_id INT NOT NULL,
    reported_by INT,
    issue_description VARCHAR(255) NOT NULL,
    request_date DATE DEFAULT (CURRENT_DATE),
    status ENUM('Open','In Progress','Resolved') DEFAULT 'Open',
    FOREIGN KEY (room_id) REFERENCES rooms(room_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (reported_by) REFERENCES staff(staff_id)
        ON DELETE SET NULL ON UPDATE CASCADE
);

-- =========================================================
-- 22. SUPPLIERS
-- =========================================================
CREATE TABLE suppliers (
    supplier_id INT AUTO_INCREMENT PRIMARY KEY,
    supplier_name VARCHAR(100) NOT NULL,
    contact_person VARCHAR(100),
    phone VARCHAR(20),
    email VARCHAR(100)
);

-- =========================================================
-- 23. INVENTORY ITEMS
-- =========================================================
CREATE TABLE inventory_items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    item_name VARCHAR(100) NOT NULL,
    category VARCHAR(50),
    unit VARCHAR(20),
    quantity_in_stock INT DEFAULT 0,
    reorder_level INT DEFAULT 10,
    supplier_id INT,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id)
        ON DELETE SET NULL ON UPDATE CASCADE
);

-- =========================================================
-- 24. PURCHASE ORDERS
-- =========================================================
CREATE TABLE purchase_orders (
    po_id INT AUTO_INCREMENT PRIMARY KEY,
    supplier_id INT NOT NULL,
    item_id INT NOT NULL,
    quantity_ordered INT NOT NULL,
    order_date DATE DEFAULT (CURRENT_DATE),
    status ENUM('Pending','Received','Cancelled') DEFAULT 'Pending',
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (item_id) REFERENCES inventory_items(item_id)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- =========================================================
-- 25. FEEDBACK / COMPLAINTS
-- =========================================================
CREATE TABLE feedback (
    feedback_id INT AUTO_INCREMENT PRIMARY KEY,
    guest_id INT NOT NULL,
    booking_id INT,
    feedback_type ENUM('Review','Complaint') DEFAULT 'Review',
    rating INT CHECK (rating BETWEEN 1 AND 5),
    comments VARCHAR(255),
    status ENUM('Open','Resolved','N/A') DEFAULT 'N/A',
    feedback_date DATE DEFAULT (CURRENT_DATE),
    FOREIGN KEY (guest_id) REFERENCES guests(guest_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id)
        ON DELETE SET NULL ON UPDATE CASCADE
);


-- =========================================================
-- SAMPLE DATA
-- =========================================================

-- 1. Departments
INSERT INTO departments (department_name, description) VALUES
('Front Desk', 'Handles guest check-in/check-out and reservations'),
('Housekeeping', 'Room cleaning and maintenance of cleanliness'),
('Food & Beverage', 'Restaurant and room service operations'),
('Maintenance', 'Repairs and technical upkeep'),
('Management', 'Overall hotel administration');

-- 2. Designations
INSERT INTO designations (title, department_id, base_salary) VALUES
('Manager', 5, 80000.00),
('Receptionist', 1, 35000.00),
('Housekeeping Staff', 2, 25000.00),
('Chef', 3, 45000.00),
('Waiter', 3, 28000.00),
('Maintenance Technician', 4, 30000.00);

-- 3. Staff
INSERT INTO staff (full_name, designation_id, phone, email, salary, hire_date) VALUES
('Usman Sheikh', 1, '03009998877', 'usman@hotel.com', 80000.00, '2022-01-15'),
('Hina Malik', 2, '03211234567', 'hina@hotel.com', 35000.00, '2023-03-10'),
('Tariq Mehmood', 3, '03331122334', 'tariq@hotel.com', 25000.00, '2023-06-01'),
('Faisal Iqbal', 4, '03451239876', 'faisal@hotel.com', 45000.00, '2021-11-20'),
('Zainab Hussain', 5, '03012223344', 'zainab@hotel.com', 28000.00, '2024-02-05'),
('Imran Qureshi', 6, '03219876543', 'imran@hotel.com', 30000.00, '2022-08-12');

-- 4. Staff Attendance
INSERT INTO staff_attendance (staff_id, attendance_date, status) VALUES
(1, '2026-06-12', 'Present'),
(2, '2026-06-12', 'Present'),
(3, '2026-06-12', 'Absent'),
(4, '2026-06-12', 'Present'),
(5, '2026-06-12', 'Leave'),
(6, '2026-06-12', 'Present');

-- 5. Payroll
INSERT INTO payroll (staff_id, month_year, amount_paid, payment_date, status) VALUES
(1, '2026-05', 80000.00, '2026-06-01', 'Paid'),
(2, '2026-05', 35000.00, '2026-06-01', 'Paid'),
(3, '2026-05', 25000.00, '2026-06-01', 'Paid'),
(4, '2026-05', 45000.00, '2026-06-01', 'Paid'),
(5, '2026-05', 28000.00, '2026-06-01', 'Pending'),
(6, '2026-05', 30000.00, '2026-06-01', 'Pending');

-- 6. Roles
INSERT INTO roles (role_name, description) VALUES
('Admin', 'Full access to all system modules'),
('Receptionist', 'Manage bookings, guests, and payments'),
('Housekeeping Staff', 'View and update room cleaning tasks');

-- 7. Users
INSERT INTO users (username, password, staff_id, role_id) VALUES
('admin', 'admin123', 1, 1),
('hina.malik', 'hina123', 2, 2),
('tariq.m', 'tariq123', 3, 3);

-- 8. Room Types
INSERT INTO room_types (type_name, price_per_night, max_occupancy, description) VALUES
('Single', 3000.00, 1, 'Single bed room with basic amenities'),
('Double', 5000.00, 2, 'Double bed room with AC and TV'),
('Deluxe', 8000.00, 3, 'Spacious room with premium facilities'),
('Suite', 15000.00, 4, 'Luxury suite with living area and minibar');

-- 9. Amenities
INSERT INTO amenities (amenity_name, icon) VALUES
('Air Conditioning', 'ac.png'),
('Wi-Fi', 'wifi.png'),
('Television', 'tv.png'),
('Mini Bar', 'minibar.png'),
('Balcony', 'balcony.png'),
('Room Heater', 'heater.png');

-- 10. Rooms
INSERT INTO rooms (room_number, type_id, floor_number, status) VALUES
('101', 1, 1, 'Available'),
('102', 1, 1, 'Occupied'),
('201', 2, 2, 'Available'),
('202', 2, 2, 'Available'),
('301', 3, 3, 'Occupied'),
('302', 3, 3, 'Maintenance'),
('401', 4, 4, 'Available');

-- 11. Room Amenities
INSERT INTO room_amenities (room_id, amenity_id) VALUES
(1,1),(1,2),(1,3),
(2,1),(2,2),(2,3),
(3,1),(3,2),(3,3),(3,5),
(4,1),(4,2),(4,3),(4,5),
(5,1),(5,2),(5,3),(5,4),(5,5),
(7,1),(7,2),(7,3),(7,4),(7,5),(7,6);

-- 12. Room Rates (Seasonal Pricing)
INSERT INTO room_rates (type_id, season_name, start_date, end_date, price_per_night) VALUES
(1, 'Summer Peak', '2026-06-01', '2026-08-31', 3500.00),
(2, 'Summer Peak', '2026-06-01', '2026-08-31', 5800.00),
(3, 'Summer Peak', '2026-06-01', '2026-08-31', 9200.00),
(4, 'Summer Peak', '2026-06-01', '2026-08-31', 17000.00),
(1, 'Winter Discount', '2026-12-01', '2027-02-28', 2500.00);

-- 13. Guests
INSERT INTO guests (full_name, cnic, phone, email, address) VALUES
('Ali Raza', '35202-1234567-1', '03001234567', 'ali.raza@gmail.com', 'Lahore, Pakistan'),
('Sara Khan', '35202-7654321-2', '03007654321', 'sara.khan@gmail.com', 'Karachi, Pakistan'),
('Bilal Ahmed', '35202-1122334-3', '03111223344', 'bilal.ahmed@gmail.com', 'Islamabad, Pakistan'),
('Ayesha Tariq', '35202-5566778-4', '03219988776', 'ayesha.tariq@gmail.com', 'Faisalabad, Pakistan');

-- 14. Discounts
INSERT INTO discounts (code, description, percentage, valid_until) VALUES
('WELCOME10', 'First-time guest discount', 10.00, '2026-12-31'),
('SUMMER20', 'Summer season offer', 20.00, '2026-08-31'),
('LOYAL15', 'Loyalty discount for returning guests', 15.00, '2026-12-31');

-- 15. Bookings
INSERT INTO bookings (guest_id, room_id, staff_id, discount_id, check_in, check_out, total_amount, booking_status) VALUES
(1, 2, 2, NULL, '2026-06-10', '2026-06-13', 9000.00, 'Checked-In'),
(2, 5, 2, 2, '2026-06-08', '2026-06-15', 44800.00, 'Checked-In'),
(3, 3, 1, NULL, '2026-06-20', '2026-06-22', 10000.00, 'Confirmed'),
(4, 1, 2, 1, '2026-05-01', '2026-05-04', 8100.00, 'Checked-Out');

-- 16. Payments
INSERT INTO payments (booking_id, amount_paid, payment_date, payment_method) VALUES
(1, 9000.00, '2026-06-10', 'Cash'),
(2, 30000.00, '2026-06-08', 'Card'),
(2, 14800.00, '2026-06-12', 'Online'),
(4, 8100.00, '2026-05-01', 'Cash');

-- 17. Refunds
INSERT INTO refunds (booking_id, refund_amount, reason, refund_date, status) VALUES
(3, 2000.00, 'Partial refund due to late cancellation policy', '2026-06-21', 'Pending');

-- 18. Services
INSERT INTO services (service_name, price, description) VALUES
('Laundry', 500.00, 'Wash and iron service per load'),
('Spa', 2500.00, 'Full body relaxation spa session'),
('Airport Pickup', 1500.00, 'Pickup from airport to hotel'),
('Gym Access', 0.00, 'Free access to hotel gym'),
('Extra Bed', 1000.00, 'Additional bed in room');

-- 19. Service Bookings
INSERT INTO service_bookings (booking_id, service_id, quantity, service_date) VALUES
(1, 1, 2, '2026-06-11'),
(2, 2, 1, '2026-06-09'),
(2, 3, 1, '2026-06-08'),
(3, 5, 1, '2026-06-20');

-- 20. Housekeeping Tasks
INSERT INTO housekeeping_tasks (room_id, staff_id, task_date, task_type, status) VALUES
(2, 3, '2026-06-12', 'Cleaning', 'Completed'),
(5, 3, '2026-06-12', 'Bed Change', 'Completed'),
(6, 3, '2026-06-12', 'Deep Clean', 'In Progress'),
(1, 3, '2026-06-13', 'Cleaning', 'Pending');

-- 21. Maintenance Requests
INSERT INTO maintenance_requests (room_id, reported_by, issue_description, request_date, status) VALUES
(6, 2, 'Air conditioner not cooling properly', '2026-06-11', 'In Progress'),
(3, 2, 'Television remote not working', '2026-06-12', 'Open'),
(5, 4, 'Bathroom tap leaking', '2026-06-10', 'Resolved');

-- 22. Suppliers
INSERT INTO suppliers (supplier_name, contact_person, phone, email) VALUES
('Fresh Foods Pvt Ltd', 'Kamran Aziz', '03001112233', 'kamran@freshfoods.com'),
('CleanCo Supplies', 'Naveed Akhtar', '03219998877', 'naveed@cleanco.com'),
('Linen World', 'Sadia Yousuf', '03334445566', 'sadia@linenworld.com');

-- 23. Inventory Items
INSERT INTO inventory_items (item_name, category, unit, quantity_in_stock, reorder_level, supplier_id) VALUES
('Bed Sheets', 'Linen', 'pcs', 120, 30, 3),
('Hand Towels', 'Linen', 'pcs', 200, 50, 3),
('Shampoo Bottles', 'Toiletries', 'pcs', 80, 20, 2),
('Rice', 'Kitchen', 'kg', 150, 50, 1),
('Cooking Oil', 'Kitchen', 'litre', 60, 20, 1),
('Cleaning Detergent', 'Cleaning', 'litre', 40, 15, 2);

-- 24. Purchase Orders
INSERT INTO purchase_orders (supplier_id, item_id, quantity_ordered, order_date, status) VALUES
(1, 4, 100, '2026-06-05', 'Received'),
(2, 6, 30, '2026-06-08', 'Received'),
(3, 1, 50, '2026-06-10', 'Pending'),
(1, 5, 40, '2026-06-11', 'Pending');

-- 25. Feedback / Complaints
INSERT INTO feedback (guest_id, booking_id, feedback_type, rating, comments, status, feedback_date) VALUES
(1, 1, 'Review', 5, 'Excellent service and clean rooms!', 'N/A', '2026-06-13'),
(2, 2, 'Review', 4, 'Good experience overall.', 'N/A', '2026-06-13'),
(4, 4, 'Review', 5, 'Will definitely visit again.', 'N/A', '2026-05-05'),
(3, 3, 'Complaint', 2, 'Room was not cleaned before check-in.', 'Open', '2026-06-20');


-- =========================================================
-- USEFUL QUERIES (for demo / viva)
-- =========================================================

-- 1. View all available rooms with type, price, and amenities
SELECT r.room_number, rt.type_name, rt.price_per_night, r.status,
       GROUP_CONCAT(a.amenity_name SEPARATOR ', ') AS amenities
FROM rooms r
JOIN room_types rt ON r.type_id = rt.type_id
LEFT JOIN room_amenities ra ON r.room_id = ra.room_id
LEFT JOIN amenities a ON ra.amenity_id = a.amenity_id
WHERE r.status = 'Available'
GROUP BY r.room_id;

-- 2. List all current bookings with guest, room and discount info
SELECT b.booking_id, g.full_name, r.room_number, b.check_in, b.check_out,
       d.code AS discount_code, b.total_amount, b.booking_status
FROM bookings b
JOIN guests g ON b.guest_id = g.guest_id
JOIN rooms r ON b.room_id = r.room_id
LEFT JOIN discounts d ON b.discount_id = d.discount_id;

-- 3. Total revenue from room bookings and extra services
SELECT 
  (SELECT IFNULL(SUM(amount_paid),0) FROM payments) AS room_revenue,
  (SELECT IFNULL(SUM(s.price * sb.quantity),0) FROM service_bookings sb JOIN services s ON sb.service_id = s.service_id) AS service_revenue;

-- 4. Guests with outstanding (unpaid) balance
SELECT g.full_name, b.booking_id, b.total_amount,
       IFNULL(SUM(p.amount_paid),0) AS paid,
       (b.total_amount - IFNULL(SUM(p.amount_paid),0)) AS balance_due
FROM bookings b
JOIN guests g ON b.guest_id = g.guest_id
LEFT JOIN payments p ON b.booking_id = p.booking_id
GROUP BY b.booking_id
HAVING balance_due > 0;

-- 5. Staff attendance summary
SELECT s.full_name, d.title,
       SUM(CASE WHEN sa.status='Present' THEN 1 ELSE 0 END) AS days_present,
       SUM(CASE WHEN sa.status='Absent' THEN 1 ELSE 0 END) AS days_absent,
       SUM(CASE WHEN sa.status='Leave' THEN 1 ELSE 0 END) AS days_leave
FROM staff s
JOIN designations d ON s.designation_id = d.designation_id
LEFT JOIN staff_attendance sa ON s.staff_id = sa.staff_id
GROUP BY s.staff_id;

-- 6. Most popular room type (by number of bookings)
SELECT rt.type_name, COUNT(b.booking_id) AS times_booked
FROM bookings b
JOIN rooms r ON b.room_id = r.room_id
JOIN room_types rt ON r.type_id = rt.type_id
GROUP BY rt.type_id
ORDER BY times_booked DESC;

-- 7. Inventory items below reorder level (need restocking)
SELECT i.item_name, i.quantity_in_stock, i.reorder_level, s.supplier_name
FROM inventory_items i
LEFT JOIN suppliers s ON i.supplier_id = s.supplier_id
WHERE i.quantity_in_stock < i.reorder_level;

-- 8. Average guest rating and open complaints
SELECT 
  (SELECT AVG(rating) FROM feedback WHERE feedback_type='Review') AS average_rating,
  (SELECT COUNT(*) FROM feedback WHERE feedback_type='Complaint' AND status='Open') AS open_complaints;

-- 9. Pending maintenance requests
SELECT m.request_id, r.room_number, m.issue_description, s.full_name AS reported_by, m.status
FROM maintenance_requests m
JOIN rooms r ON m.room_id = r.room_id
LEFT JOIN staff s ON m.reported_by = s.staff_id
WHERE m.status != 'Resolved';

-- 10. Pending payroll for current month
SELECT s.full_name, d.title, p.month_year, p.amount_paid, p.status
FROM payroll p
JOIN staff s ON p.staff_id = s.staff_id
JOIN designations d ON s.designation_id = d.designation_id
WHERE p.status = 'Pending';
